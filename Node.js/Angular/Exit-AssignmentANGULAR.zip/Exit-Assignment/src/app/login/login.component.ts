import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';

import {AuthService} from '../auth.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username:string;
  password:string;
  constructor(private Auth:AuthService,private router: Router,private route:ActivatedRoute) { }
  
  ngOnInit() {
  }
  loginUser()
  {
    event.preventDefault();
   const target = event.target;
  //    const u = target.getElementById('username');
  //  const p = target.querySelector('#password').value;
    //  console.log(u + p);
    let u = this.username;
     let p = this.password;
    console.log("hello");
    this.Auth.getUserDetail(u,p).subscribe((d)=>{
      console.log(d);
      
    if(d==1)
    {
      this.Auth.getUserId(u,p).subscribe((id)=>{
        console.log(id);
        let key = 'ID';
        localStorage.setItem(key,id.toString());
      this.router.navigate(['/volunteer/'+id]);
      })
      
    }
    else if(d==2)
    {
      let key = 'ID';
      let id = 1;
        localStorage.setItem(key,id.toString());
      this.router.navigate(['/approver/pendingvolunteer']);
    }

    else
    {
      alert("Invalid UserName or Password");
    }
    }
    ,
    (error)=>{
      console.log("Error = "+ error)
    });
  }
  save(state:boolean)
  {
    if(state==false)
      alert("Please fill the Username password correctly");
      else
      this.loginUser();
  }
  register(){
    this.router.navigate(['/register'])
  }

}
