import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {AuthService} from '../../auth.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-national-population-record',
  templateUrl: './national-population-record.component.html',
  styleUrls: ['./national-population-record.component.css']
})



// enum gender{
//   male=  8,female,others
// }

// enum marital{
//   single=11,married,divorced,widow
// }
// enum OccupationStatus{
//   employed = 15,
//   selfEmployed,
//   student
// }


export class NationalPopulationRecordComponent implements OnInit {
  
  FullName:string;
  CensusNumber:string;
  RelatioshiptoHead:string;
  Gender:string;
  dob:string;
  MaritalStatus:string;
  AgeAtMarriage:number;
  OccupationStatus:string;
  NatureOfOccupation:string;

  isMarried = false;
  createdByUser = this.route.snapshot.paramMap.get('id');
  houseurl = '/hosuelisting/'+ this.createdByUser;
   nationalurl = '/nationalpopulation/' + this.createdByUser;
  id;
  

  constructor(private Auth:AuthService,private route: ActivatedRoute,private router : Router) { }

  ngOnInit() {
    this.id = this.route.snapshot.paramMap.get('id');
    if(localStorage.getItem('ID')!=this.id)
      this.router.navigate(['/login']);
  }


  onChange(event)
  {
    if(event=='Single')
      this.isMarried = true;
      else
      this.isMarried = false
    
  }
  addNationalRecord()
  {
    let obj = {
      'FullName':this.FullName,
      'DateOfBirth':this.dob,
      'Age':this.AgeAtMarriage,
      'NatureOfOccupation':this.NatureOfOccupation,
       'CensusHouseNumber':this.CensusNumber,
      'Gender':this.Gender,
      'OccupationStatus':this.OccupationStatus,
      'CurrentMaritalStatus':this.MaritalStatus,
      'RelationshipToHead':this.RelatioshiptoHead
    }
    console.log(obj);
    this.Auth.AddNationalRecord(obj).subscribe((d)=>{
      if(d==true)
      {
        alert("Record is added succesfully");
        window.location.reload();
      }  
        else
        alert("The Census Hosue Number is INVALID");
    })
  }


  save(state:boolean)
  {
    console.log(state)
    if(!state){
      alert("please fill the form corretly");
    }
    else{
      this.addNationalRecord();
    }
  }
  navigate1()
  {
    this.router.navigate([this.houseurl]);
  }
  navigate2()
  {
    this.router.navigate([this.nationalurl]);
  }


  logout()
  {
    localStorage.clear();
    this.router.navigate(['/login']);
  }

}
