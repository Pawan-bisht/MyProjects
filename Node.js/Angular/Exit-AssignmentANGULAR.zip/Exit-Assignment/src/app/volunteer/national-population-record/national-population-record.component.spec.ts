import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NationalPopulationRecordComponent } from './national-population-record.component';

describe('NationalPopulationRecordComponent', () => {
  let component: NationalPopulationRecordComponent;
  let fixture: ComponentFixture<NationalPopulationRecordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NationalPopulationRecordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NationalPopulationRecordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
