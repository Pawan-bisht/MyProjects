import { Component, OnInit } from '@angular/core';
import {AuthService} from '../../auth.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
@Component({
  selector: 'app-house-listing',
  templateUrl: './house-listing.component.html',
  styleUrls: ['./house-listing.component.css']
})
export class HouseListingComponent implements OnInit {

  buildingNumber:number;
  Address:string;
  state:string;


  FullNameOfHead:string;
  OwnerShipStatus:string;
  numberOfRooms:number;
   createdByUser = this.route.snapshot.paramMap.get('id');
   houseurl = '/hosuelisting/'+ this.createdByUser;
   nationalurl = '/nationalpopulation/' + this.createdByUser;
  
   constructor(private Auth:AuthService,private route: ActivatedRoute,private router : Router) { }
id;
  ngOnInit() {
    this.id = this.route.snapshot.paramMap.get('id');
    if(localStorage.getItem('ID')!=this.id)
      this.router.navigate(['/login']);
  }
  addHouseList()
  {
    let statush;
    
    if(this.OwnerShipStatus=='OWNER')
      statush = 1;
      else
      statush  =0 ;
    let obj = {
      'BuildingNumber':this.buildingNumber,
      'Address': this.Address,
      'State' : this.state,
      'FullNameOfHead':this.FullNameOfHead,
      'NumberOfRooms' :this.numberOfRooms,
      'OwnerShipStatus': statush,
      'CreatedBy' : this.createdByUser
    }
    
     console.log(obj);
     return this.Auth.AddHouseListing(obj).subscribe((d)=>console.log(alert(d + "   please save it for further verification(or proceed to national population record)")));
     window.location.reload();
    
     // console.log(this.Address);
    // console.log(this.state);
    // console.log(this.FullNameOfHead);
    // console.log(this.OwnerShipStatus);
    // console.log(this.numberOfRooms);
  }
  save(state:boolean)
  {
    if(state==false)
    {
      alert("please fill  the form coorectly"); 
    }
      
      else
      this.addHouseList();
  }
  navigate1()
  {
    this.router.navigate([this.houseurl]);
  }
  navigate2()
  {
    this.router.navigate([this.nationalurl]);
  }

  logout()
  {
    localStorage.clear();
    this.router.navigate(['/login']);
  }


}
