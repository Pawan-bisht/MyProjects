import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router, Route } from '@angular/router';

@Component({
  selector: 'app-agewise',
  templateUrl: './agewise.component.html',
  styleUrls: ['./agewise.component.css']
})
export class AgewiseComponent implements OnInit {

  constructor(private Auth:AuthService,private router:Router) { }

  obj: any;
  labels: string[];
  data: number[];
  chartOptions = {
    scales: {
      yAxes:[{
        ticks: {
          beginAtZero: true
        }
      }]
    }
  }
  ngOnInit() {
    this.obj = null;  
    this.labels= [];
  this.data = []
    this.Auth.GetAgeOfpopulation().subscribe((d) => {
      console.log(d);
      this.obj = d;
      console.log(this.obj)
      
    })
  }

  back()
  {
    this.router.navigate(['approver/pendingvolunteer'])
  }
}
