import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgewiseComponent } from './agewise.component';

describe('AgewiseComponent', () => {
  let component: AgewiseComponent;
  let fixture: ComponentFixture<AgewiseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgewiseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgewiseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
