import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http : HttpClient) { }

  getUserDetail(username,password){
    console.log(username);
    return this.http.post('http://localhost:51851/api/user/Login',{
      "Email":username,
      "Password":password
    })

  }

getUserId(username,password)
{
  return this.http.post('http://localhost:51851/api/user/GetVolunteerId/',
  {
    "Email":username,
      "Password":password    
})
}


getUserRequestStatus(userId)
{
  console.log(userId+'mami');
  let id = parseInt(userId);
  var request;
  console.log(typeof id);
    return this.http.get('http://localhost:51851/api/User/GetVolunteerRequestStatus?userId='+id);
    //return request;
  //return request;
}

  postUserDetail(obj)
  {
     console.log(obj);
     return this.http.post('http://localhost:51851/api/user/Post',obj);
     
  }

  getApprovedUser()
  {
    return this.http.get('http://localhost:51851/api/user/GetSpecificUsers?request=approved')
  }
  getPendinguser()
  {
    return this.http.get('http://localhost:51851/api/user/GetSpecificUsers?request=pending')
  }

  getDeclinedUser()
  {
    return this.http.get('http://localhost:51851/api/user/GetSpecificUsers?request=declined')
  }

  pendingToApproved(id)
  {
    return this.http.put('http://localhost:51851/api/user/PendingToApproved/' + id,{}).subscribe(data=>{
      console.log(data);
    })
  }

  pendingToDeclined(id)
  {
    return this.http.put('http://localhost:51851/api/user/PendingToDeclined/' + id,{}).subscribe(data=>{
      console.log(data);
    })
  }
  
  AddHouseListing(obj)
  {
    return this.http.post('http://localhost:51851/api/HouseListing/AddHouse',obj);
  }

  AddNationalRecord(obj)
  {
    return this.http.post('http://localhost:51851/api/NationalPopulation/AddPersonIntoNationalPopulation',obj);
  }


  GetStatePopulation()
  {
    return this.http.get("http://localhost:51851/api/HouseListing/GetStatewisePopulation");
  }

  GetAgeOfpopulation()
  {
    return this.http.get("http://localhost:51851/api/NationalPopulation/GetAges");
  }

}




