import { Component, OnInit } from '@angular/core';
import {AuthService} from '../../auth.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-declined-volunteer',
  templateUrl: './declined-volunteer.component.html',
  styleUrls: ['./declined-volunteer.component.css']
})
export class DeclinedVolunteerComponent implements OnInit {

  listDeclined;
  constructor(private Auth : AuthService,private router : Router) { }

 async ngOnInit() {
    if(localStorage.getItem('ID')!="1"){
      this.router.navigate(['/login']);
    }
    this.Auth.getDeclinedUser().subscribe((d)=>{
      console.log(d);
      this.listDeclined= d;
      },
      (error)=>{
      console.log("Error => "+error);
      })
  }
  redirect(event)
  {
    this.router.navigate([event]);
    console.log("u clicked");
  }
  logout()
  {
    localStorage.clear();
    this.router.navigate(['/login'])
  }
  state()
  {
    this.router.navigate(['/statewisepopulatoin'])
  }
  age()
  {
    this.router.navigate(['/agewise']);
  }
}
