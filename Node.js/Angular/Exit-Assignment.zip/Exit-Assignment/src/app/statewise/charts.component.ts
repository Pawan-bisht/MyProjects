import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-charts',
  templateUrl: './charts.component.html',
  styleUrls: ['./charts.component.css']
})
export class ChartsComponent implements OnInit {

  constructor(private Auth: AuthService,private router:Router) { }
  obj: any;
  labels: string[];
  data: number[];
  chartOptions = {
    scales: {
      yAxes:[{
        ticks: {
          beginAtZero: true
        }
      }]
    }
  }

  ngOnInit() {
    this.obj = null;  
    this.labels= [];
  this.data = []
    this.Auth.GetStatePopulation().subscribe((d) => {
      console.log(d);
      this.obj = d;
      console.log(this.obj)
      this.obj.forEach(element => {
        this.labels.push(element.Key)
        this.data.push(element.Count)
      });
    })
  }
  back()
  {
    this.router.navigate(['approver/pendingvolunteer'])
  }
}
