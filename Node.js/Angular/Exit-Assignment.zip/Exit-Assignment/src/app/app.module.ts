import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{LoginComponent} from './login/login.component';
import{RegisterComponent} from './register/register.component';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import {RouterModule,Routes} from '@angular/router';
import {FormsModule} from '@angular/forms';
import { Route } from '@angular/compiler/src/core';
import { VolunteerComponent } from './volunteer/volunteer.component';
import { ApproverComponent } from './approver/approver.component';
import {NgxPaginationModule} from 'ngx-pagination';
import { PendingVolunteerComponent } from './approver/pending-volunteer/pending-volunteer.component';
import { ApprovedVolunteerComponent } from './approver/approved-volunteer/approved-volunteer.component';
import { DeclinedVolunteerComponent } from './approver/declined-volunteer/declined-volunteer.component';
import { HouseListingComponent } from './volunteer/house-listing/house-listing.component';
import { NationalPopulationRecordComponent } from './volunteer/national-population-record/national-population-record.component';
import { ChartsComponent } from './statewise/charts.component';
import { ChartsModule} from 'ng2-charts';
import { AgewiseComponent } from './agewise/agewise.component'

const appRoutes : Routes =[

  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'',
    redirectTo:'login',
   
    pathMatch:'full'
  },
  
  {
    path:'register',
    component:RegisterComponent
  },
  {
    path:'approver',
    component:ApproverComponent
  },
  {
    path:'volunteer/:id',
    component: VolunteerComponent
  },
  {
    path:'approver/pendingvolunteer',
    component:PendingVolunteerComponent
  },
  {
    path:'approver/approvedvolunteer',
    component:ApprovedVolunteerComponent
  },
  {
    path:'approver/declinedvolunteer',
    component:DeclinedVolunteerComponent
  },
  {
    path:'hosuelisting/:id',
    component:HouseListingComponent
  },
  {
    path:'nationalpopulation/:id',
    component:NationalPopulationRecordComponent
  },
  {
    path:"statewisepopulatoin",
    component:ChartsComponent
  },
  {
    path :"agewise",
    component:AgewiseComponent
  }
]

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    VolunteerComponent,
    ApproverComponent,
    
    PendingVolunteerComponent,
    ApprovedVolunteerComponent,
    DeclinedVolunteerComponent,
    HouseListingComponent,
    NationalPopulationRecordComponent,
    ChartsComponent,
    AgewiseComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    ChartsModule,
    NgxPaginationModule,
    RouterModule.forRoot(
      appRoutes
    )
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
