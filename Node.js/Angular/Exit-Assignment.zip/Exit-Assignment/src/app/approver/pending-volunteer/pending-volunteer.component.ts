import { Component, OnInit } from '@angular/core';
import {AuthService} from '../../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pending-volunteer',
  templateUrl: './pending-volunteer.component.html',
  styleUrls: ['./pending-volunteer.component.css']
})
export class PendingVolunteerComponent implements OnInit {

  address = ["g/13 Pune building number 12 ",
              "Anjana aparment lodhi road  new delhi",
              "Kamal apartment hosue number 501 sector 9 rohini new delhi",
              "vikar puri govt quarter falt numner 45 ",
              "79 New Saddle Ave.Hernando, MS 38632",
              "402 - Swarna Jayanti Sadan Deluxe, Dr. B.D. Marg, New Delhi 110001",
              "Peevees Mirage, Nilambur P.O., Malappuram District, Kerala. 679329",
              "At-Chanchala Niwas, Ward No-16, PO-Bargarh, Dist.-Bargarh, Odisha 768028",
              "Bunglow No.9, Teen Murti Lane, New Delhi 110011",
              "'Anjanam', Easwara Vilasam Road, Thiruvananthapuram 695014"]
   states = ["Delhi ","punjab","haryana","uttar pradesh","Tamil nadu","kerala","rajasthan","gujarat","Mumbai","Himachal pradesh"];           

  index =  Math.floor(Math.random() * 10) + 1;  


  constructor(private Auth:AuthService,private router : Router) { }
 listPending;
 id:number;
 pendingToDeclined(event)
 {
  var target = event.target || event.srcElement || event.currentTarget;
  var idAttr = target.attributes.id;
  this.id = idAttr.nodeValue;
   this.Auth.pendingToDeclined(this.id);
   window.location.reload();
 }
 pendingToApprove(event)
 {
  var target = event.target || event.srcElement || event.currentTarget;
  var idAttr = target.attributes.id;
  this.id = idAttr.nodeValue;
   this.Auth.pendingToApproved(this.id);
   window.location.reload();
 }
  ngOnInit() {
    if(localStorage.getItem('ID')!="1"){
      this.router.navigate(['/login']);
    }
    this.Auth.getPendinguser().subscribe((d)=>{
      console.log(d);
      this.listPending= d;
      },
      (error)=>{
      console.log("Error => "+error);
      })
  }

  redirect(event)
  {
    this.router.navigate([event]);
    console.log("u clicked");
  }
  logout()
  {
    localStorage.clear();
    this.router.navigate(['/login'])
  }

  state()
  {
    this.router.navigate(['/statewisepopulatoin'])
  }
  age()
  {
    this.router.navigate(['/agewise']);
  }
}
