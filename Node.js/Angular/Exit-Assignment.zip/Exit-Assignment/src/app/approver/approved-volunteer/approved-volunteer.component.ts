import { Component, OnInit } from '@angular/core';
import {AuthService} from '../../auth.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-approved-volunteer',
  templateUrl: './approved-volunteer.component.html',
  styleUrls: ['./approved-volunteer.component.css']
})
export class ApprovedVolunteerComponent implements OnInit {

  constructor(private Auth:AuthService,private router : Router) { }
 listApproved;
  async ngOnInit() {
    if(localStorage.getItem('ID')!="1"){
      this.router.navigate(['/login']);
    }
    this.Auth.getApprovedUser().subscribe((d)=>{
      console.log(d);
      this.listApproved= d;
      },
      (error)=>{
      console.log("Error => "+error);
      })
  }
  redirect(event)
  {
    this.router.navigate([event]);
    console.log("u clicked");
  }
 
  logout()
  {
    localStorage.clear();
    this.router.navigate(['/login'])
  }
  state()
  {
    this.router.navigate(['/statewisepopulatoin'])
  }
  age()
  {
    this.router.navigate(['/agewise']);
  }
}
