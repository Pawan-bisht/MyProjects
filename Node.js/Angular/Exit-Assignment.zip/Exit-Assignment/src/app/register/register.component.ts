import { Component, OnInit } from '@angular/core';
import {AuthService} from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  email :string;
  password:string;
  firstname:string;
  lastname:string;
  adharnumber:string;
 image;


  adharerrormessage = "";
  firstnamemessage = "";
  lastnamemesaage = "";

  passworderrormessage = "";
  constructor(private Auth:AuthService,private router: Router) { }
  
  registerUser()
  {
     let obj = {
       'Email':this.email,
       'Password':this.password,
       'FirstName':this.firstname,
       'LastName':this.lastname,
       'AdharNumber':this.adharnumber,
       'RequestStatus':3,
       'UserType':1,
       'Image':this.image
     }
     let val = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$/;
     
  
//this.password.search(/[a-z]/i) < 0) || this.password.search(/[0-9]/) < 0 ||this.password.length < 8
  // if ( (this.password.search(/[a-z]/i) < 0)||(this.password.search(/[0-9]/) < 0)|| (this.password.length < 8)||(this.password.search(/^[a-zA-Z0-9!@#\$%\^\&*\)\(+=._-]+$/)<0 )) {
  //   this.passworderrormessage = " password Length is not shorter than 8 Your password must contain at least one letter.  Your password must contain at least one digit. Your password must contain atleat one special character";
  //   console.log(this.password);
  //   return;
  // }
      if(!this.password.match(val))
      {
        this.passworderrormessage = "wrong pattern password Length is not shorter than 8 Your password must contain at least one letter.  Your password must contain at least one digit. Your password must contain atleat one special character"; 
        return ;
      }
      else
      {
        this.Auth.postUserDetail(obj).subscribe((d)=>{
          if(d==true)
          {
            alert("Added Succesfully");
            this.router.navigate(['/login']);
          }
          else
          {
              alert("Adhar number or Email Id is already Existed");
          }
       }) 
      console.log(obj);
      }
     
    }
  

  ngOnInit() {
  }
  readThis(files: FileList){

    var reader = new FileReader();
    // Read file into memory as UTF-16 
    reader.readAsDataURL(files[0]);
    reader.onload = (e)=> {
     this.image=reader.result.toString();
    // this.user.Image = reader.result.toString();
    } }

  save(state:boolean)
  {
    if(state==false)
      alert("please fill all the fields correctly")
    else
    {
       this.registerUser();
      
    }  
  }
}
