import { Component, OnInit } from '@angular/core';
import {AuthService} from '../auth.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
@Component({
  selector: 'app-volunteer',
  templateUrl: './volunteer.component.html',
  styleUrls: ['./volunteer.component.css']
})
export class VolunteerComponent implements OnInit {

  constructor(private Auth:AuthService,private route: ActivatedRoute,private router : Router) { }
  id;
  
  userId;
  isDisabled;
  requestStatus;
  requestMessage;
  url;
   async ngOnInit() { 
    this.id=this.route.snapshot.paramMap.get('id');
    if(localStorage.getItem('ID')!=this.id){
    this.router.navigate(['']);
    }
   // console.log(this.route.snapshot.paramMap.get('id')+'pawan');
    this.userId = this.route.snapshot.paramMap.get('id');
    this.url = "/hosuelisting/" + this.userId;
    let requeststatus =  this.Auth.getUserRequestStatus(this.userId).subscribe((d)=>{
      console.log("data => ")
      this.requestStatus = d;
      if(d==3)
      {
        console.log("pending");
        this.isDisabled = true;
        this.requestMessage = "Your Request is still pending";
      }
      
      else if(d==4)
      {
        console.log('declined');
        this.isDisabled = true;
        this.requestMessage = "Your Request has been declined";
      }
      
      else
      {
        console.log(d);
        this.isDisabled = false;
        this.requestMessage = "Your request is approved Please Proceed to Further Verification!"
      }
      
    },
    (error)=>{
      console.log("error => ")
      console.log(error.error)
    });
    // await delay(1000);
    // console.log('yes we are here '+ requeststatus);
    // console.log( requeststatus)

  }


  navigate()
  {
    this.router.navigate([this.url]);
    
  }
  logout()
  {
    localStorage.clear();
    this.router.navigate(['/login']);
  }

}
