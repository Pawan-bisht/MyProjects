const Sequelize = require('sequelize')
const Op = Sequelize.Op

const db = new Sequelize({
    dialect: 'sqlite', 
    storage: __dirname + '/ShopManager.db'
})

const Vendors = db.define('vendor', {
    name: {
      type: Sequelize.STRING,
      allowNull: false
    }
})

const Products = db.define('product',{
    name: {
        type: Sequelize.STRING,
        allowNull: false
    },
    quantity: {
        type: Sequelize.INTEGER,
        allowNull: false
    },
    remainingQty: {
        type: Sequelize.INTEGER,
        allowNull: false
    },
    price: {
        type:Sequelize.INTEGER,
        allowNull: false
    }
})

const Users = db.define('user', {
    name: {
      type: Sequelize.STRING,
      allowNull: false
    }
})

const Cart = db.define('cart',{
    quantityAdded: {
        type: Sequelize.INTEGER,
        allowNull: false
    }
})

Vendors.hasMany(Products)
Products.belongsTo(Vendors)

Users.hasMany(Cart)
Cart.belongsTo(Users)

Products.hasMany(Cart)
Cart.belongsTo(Products)

module.exports= {
    db,Vendors,Products,Users,Cart
}