const express = require('express')
const {
  db,
  Vendors,
  Products,
  Users,
  Cart
} = require('./db')

const app = express()

app.use(express.static(__dirname + '/public'))

app.use(express.json())
app.use(express.urlencoded({
  extended: true
}))


app.get('/vendors', async (req, res) => {
  const vendors = await Vendors.findAll()
 res.send(vendors);
})
app.get('/', async (req, res) => {
 res.sendFile(__dirname+"/public/index.html");
})
app.post('/', async (req, res) => {
  try {
    const result = await Vendors.create({
      name: req.body.name
    })
    res.send({success: true})
  } catch (e) {
    res.send({success: false, err: e.message})
  }
})


db.sync({force:true})
  .then(() => {
    Users.create({name: 'yash'})
    Users.create({name: 'Ramesh'})
    Users.create({name: 'Suresh'})
    Vendors.create({name: 'Apple'})
    Vendors.create({name: 'Samsung'})
    Vendors.create({name: 'RedMi'})
    Products.create({name: 'IPhone7', quantity: 23, remainingQty: 7, price:65000, vendorId: 1})
    Products.create({name: 'Samsung A7', quantity: 25, remainingQty: 14, price:30000, vendorId: 2})
    Products.create({name: 'RedMi Note 7 Pro', quantity: 30, remainingQty: 30, price:15000, vendorId: 3})
    Products.create({name: 'Mi A2', quantity: 36, remainingQty: 26, price:25000, vendorId: 3})
    Products.create({name: 'IPhone X', quantity: 42, remainingQty: 30, price:95000, vendorId: 1})
    Cart.create({quantityAdded: 12, userId: 1, productId: 5})
    Cart.create({quantityAdded: 10, userId: 1,productId: 4})
    Cart.create({quantityAdded: 16, userId: 3,productId: 1})
    Cart.create({quantityAdded: 11, userId: 2,productId: 2})
    app.listen(8090)
})