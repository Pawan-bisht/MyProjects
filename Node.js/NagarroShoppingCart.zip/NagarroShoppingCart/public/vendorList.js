$(()=>{
    function refreshList() {
        $.get('/', (data) => {
          $('#vendorlist').empty()
            let count=1;
            console.log(data);
          for (let vendor of data) {
            $('#vendorlist').append(
              `<li>  ${vendor.name}  <button  id=${count}>&#10006;</button> </li>`
            )
            count++;
          }
        })
    }

    refreshList();

    function check(value){
        if(value==''){
          return false;
        }
        else
        {
          return true;
        }
    }

    $('#addvendor').click(() => {
        if(check($('#vendor').val())){
          $('#vendor').empty()
          $.post(
            '/',
            {
              name: $('#vendor').val()
            },
            (data) => {
              if (data.success) {
                refreshList()
              } else {
                alert('Some error occurred')
              }
            }
          )
        }
        else {
          alert('Please ! Enter Vendor\'s name')
        }
    })
})